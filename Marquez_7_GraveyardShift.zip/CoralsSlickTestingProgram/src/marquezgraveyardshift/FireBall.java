/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marquezgraveyardshift;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

/**
 *
 * @author aflynn
 */
public class FireBall {
    private int x, y, width, height;
    private int dmg , locationX , locationY;
    private boolean isVisible;
    private int direction; 
    private int timeexists;
    private int mydirection;
    Image orb;
    Shape hitbox;
   
    public FireBall (int a, int b) throws SlickException {
        this.x = a;
        this.y = b;
        this.isVisible = false;
        this.orb = new Image ("res/orbs/Ninja_14.png");
        this.hitbox = new Rectangle (a, b, 32, 32);
        this.timeexists = 0;
}
     public void setTimeexists(int timeexists) {
        this.timeexists = timeexists;
    }

    public void setMydirection(int mydirection) {
        this.mydirection = mydirection;
    }

    public int getTimeexists() {
        return timeexists--;
    }

    public int getMydirection() {
        return mydirection;
    }
    
   
    

    public void countdown(){
        this.timeexists --;
    }
    public void setDirection(int i){
        this.direction = i;
    }
    
    public int getDirection(){
        return this.direction;
    }
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getDmg() {
        return dmg;
    }

    public int getLocationX() {
        return locationX;
    }

    public int getLocationY() {
        return locationY;
    }

    public boolean isIsVisible() {
        return isVisible;
    }

    public Image getOrb() {
        return orb;
    }

    public Shape getHitbox() {
        return hitbox;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setDmg(int dmg) {
        this.dmg = dmg;
    }

    public void setLocation() {
    }

    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    public void setOrb(Image orb) {
        this.orb = orb;
    }

    public void setHitbox(Shape hitbox) {
        this.hitbox = hitbox;
    }
}
