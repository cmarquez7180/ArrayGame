package marquezgraveyardshift;

import org.newdawn.slick.state.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import org.newdawn.slick.tiled.TiledMap;
import org.w3c.dom.css.Rect;

public class GraveyardShiftlvl1 extends BasicGameState {

        static int timer = 0;
        static int freeze = 0;
        public Bone bone1, bone2;
        public FoxHole trap1;
        public Enemy flava, flav;
        public Orb ball;
        public Weapon sphere;
        public FireBall magic;
        public static Player skully;
        
        public ArrayList<FoxHole> hole = new ArrayList();
        public static ArrayList<Bone> doghouse = new ArrayList();
        public ArrayList<Enemy> bonez = new ArrayList();
        private boolean[][] hostiles;
        
	public static TiledMap grassMap;

	private static AppGameContainer app;

	private static Camera camera;
	
	public static int counter = 0;

	private static final int SIZE = 64;

	private static final int SCREEN_WIDTH = 1000;

	private static final int SCREEN_HEIGHT = 750;
        
       

	public GraveyardShiftlvl1(int xSize, int ySize) {

	}

	public void init(GameContainer gc, StateBasedGame sbg)

	throws SlickException {
		
		 gc.setTargetFrameRate(60);

		gc.setShowFPS(false);

                grassMap = new TiledMap("res/coral.tmx");


		camera = new Camera(gc, grassMap);

		Blocked.blocked = new boolean[grassMap.getWidth()][grassMap.getHeight()];

		for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {

			for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {

				int tileID = grassMap.getTileId(xAxis, yAxis, 1);

				String value = grassMap.getTileProperty(tileID,

				"blocked", "false");

				if ("true".equals(value)) {

					Blocked.blocked[xAxis][yAxis] = true;

				}

			}

		}
                 hostiles = new boolean[grassMap.getWidth()][grassMap.getHeight()];

        for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {
            for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
                int xBlock = (int) xAxis;
                int yBlock = (int) yAxis;
                if (!Blocked.blocked[xBlock][yBlock]) {
                    if (yBlock % 15 == 0 && xBlock % 15 == 0) {
                        FoxHole f = new FoxHole(xAxis * SIZE, yAxis * SIZE);
                        hole.add(f);
                        //stuff1.add(h);
                        hostiles[xAxis][yAxis] = true;
                    }
                }
            }
        }
                
                flava = new Enemy(1500, 2500);
                flav = new Enemy(1000, 1000);
                bonez.add(flava);
                bonez.add(flav);
                
                skully = new Player(1000, 1000);
                
                trap1 = new FoxHole(400,500);
                hole.add(trap1);
                
                bone1 = new Bone(655,70);
                bone2 = new Bone(1750,800);
                doghouse.add(bone1);
                doghouse.add(bone2);
                
                ball = new Orb((int)Player.x + 5,(int) Player.y - 10);
                
                sphere = new Weapon((int)Player.x + 5,(int) Player.y - 10);
                
                magic = new FireBall((int)Player.x + 5,(int) Player.y - 10);
                
                BoneMaker.Makethebones();
                
	}

	public void render(GameContainer gc, StateBasedGame sbg, Graphics g)

	throws SlickException {

		camera.centerOn((int) Player.x, (int) Player.y);

		camera.drawMap();

		camera.translateGraphics();
		
		g.drawString("speed: " + (int)(skully.speed *10), camera.cameraX + 10,
				camera.cameraY + 25);
                g.drawString("bone: " + (int)(Player.Counter *1), camera.cameraX + 10,
				camera.cameraY + 10);
		g.drawString("time passed: " +counter/1000, camera.cameraX +600,camera.cameraY );
                
                if (timer > 0) {
                    g.drawString("interitio: " + (int)(Player.maxballs *1), skully.getplayersX() + 60,
				skully.getplayersY() + 5);
                    g.drawString("debilitas: " + (int)(Player.maxsphere *1), skully.getplayersX() + 60,
				skully.getplayersY() + 25);
                    g.drawString("exordium: " + (int)(Player.maxmagic *1), skully.getplayersX() + 60,
				skully.getplayersY() + 45);
                
                timer --;
                }

                for (FoxHole f : hole) {
			if (f.isvisible) {
				f.currentImage.draw(f.x, f.y);
                                
			}
		}
                
			if (skully.isAlive) {
				skully.sprite.draw(skully.x, skully.y);
                                
			}
                
                
                for (Bone b : doghouse) {
			if (b.isvisible) {
				b.currentImage.draw(b.x, b.y);
                                
			}
		}
                
			if (skully.isAlive) {
				skully.sprite.draw(skully.x, skully.y);
                                
			}
                        

                for (Enemy e : bonez) {
			if (e.isAlive) {
				e.currentanime.draw(e.Bx, e.By);

			}
		}

                if (ball.isIsVisible()) {
                    ball.orb.draw(ball.getX(), ball.getY());
                    //ballup
                }
                
                if (sphere.isIsVisible()) {
                    sphere.orb.draw(sphere.getX(), sphere.getY());
                    //ballup
                }
                if (magic.isIsVisible()) {
                    magic.orb.draw(magic.getX(), magic.getY());
                    //ballup
                }
                

	}

	public void update(GameContainer gc, StateBasedGame sbg, int delta)

	throws SlickException {
            

		counter += delta;
                

                Input input = gc.getInput();

		float fdelta = delta * skully.speed;

		skully.setpdelta(fdelta);

		double rightlimit = (grassMap.getWidth() * SIZE) - (SIZE * 0.75);

		float projectedright = Player.x + fdelta + SIZE;

		boolean cangoright = projectedright < rightlimit;

		if (input.isKeyDown(Input.KEY_UP)) {
                    skully.setDirection(0);

			skully.sprite = skully.up;

			float fdsc = (float) (fdelta - (SIZE * .15));

			if (!(isBlocked(Player.x, Player.y - fdelta) || isBlocked((float) (Player.x + SIZE + 1.5), Player.y - fdelta))) {

				skully.sprite.update(delta);

				Player.y -= fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_DOWN)) {
                    skully.setDirection(2);

			skully.sprite = skully.down;

			if (!isBlocked(Player.x, Player.y + SIZE + fdelta)

			|| !isBlocked(Player.x + SIZE - 1, Player.y + SIZE + fdelta)) {

				skully.sprite.update(delta);

				Player.y += fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_LEFT)) {
                    skully.setDirection(3);

			skully.sprite = skully.left;

			if (!(isBlocked(Player.x - fdelta, Player.y) || isBlocked(Player.x

			- fdelta, Player.y + SIZE - 1))) {

				skully.sprite.update(delta);

				Player.x -= fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_RIGHT)) {
                    skully.setDirection(1);
			skully.sprite = skully.right;
			if (cangoright
					&& (!(isBlocked(Player.x + SIZE + fdelta,
					Player.y) || isBlocked(Player.x + SIZE + fdelta, Player.y
							+ SIZE - 1)))) {
				skully.sprite.update(delta);
				Player.x += fdelta;
			} 
		} else if (input.isKeyPressed(Input.KEY_SPACE)) {
                    if (skully.maxballs > 0) {
                    ball.setDirection(skully.getDirection());
                    ball.setTimeexists(200);
                    ball.setX((int)skully.x);
                    ball.setY((int)skully.y);
                    ball.hitbox.setX(ball.getX());
                    ball.hitbox.setY(ball.getY());
                    ball.setIsVisible(!ball.isIsVisible());
                    skully.maxballs -= 1;
                    }
                    //ball.setIsVisible(true);
                } else if (input.isKeyPressed(Input.KEY_B)) {
                    if (skully.maxsphere > 0) {
                    sphere.setDirection(skully.getDirection());
                    sphere.setTimeexists(200);
                    sphere.setOrbEffect(800);
                    sphere.setX((int)skully.x);
                    sphere.setY((int)skully.y);
                    sphere.hitbox.setX(sphere.getX());
                    sphere.hitbox.setY(sphere.getY());
                    sphere.setIsVisible(!sphere.isIsVisible());
                    skully.maxsphere -= 1;
                    freeze = 3;
                    }
                } else if (input.isKeyPressed(Input.KEY_V)) {
                    if (skully.maxmagic> 0) {
                    magic.setDirection(skully.getDirection());
                    magic.setTimeexists(200);
                    magic.setX((int)skully.x);
                    magic.setY((int)skully.y);
                    magic.hitbox.setX(magic.getX());
                    magic.hitbox.setY(magic.getY());
                    magic.setIsVisible(!magic.isIsVisible());
                    skully.maxmagic -= 1;
                    }
                } else if (input.isKeyPressed(Input.KEY_I)) {
                    // counter of Time bombs, killers, & relocators
                    timer = 100;
                    
                }
                

		skully.rect.setLocation(skully.getplayershitboxX(),
				skully.getplayershitboxY());
                
                for (Bone b : doghouse) {

			if (skully.rect.intersects(b.hitbox)) {
				if (b.isvisible) {
					skully.speed += .1f;
                                        b.isvisible = false;
                                        Player.Counter += 1;
				}

			}
                
                        if (skully.Counter > 3) {
                        Bone.Counter = false;
			sbg.enterState(7, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
                        
         }
                }
                for (FoxHole f : hole) {

			if (skully.rect.intersects(f.hitbox)) {
				if (f.isvisible) {
					skully.stamina = 1;
				}

			}
                }
		 
                 for (Enemy e : bonez) {
			if (e.isAlive) {
                            e.move();
                             }}
                 for (Enemy e : bonez) {
			if (e.isAlive) {
                        if (skully.rect.intersects(e.rect)){
                            skully.health = 0;
                            //e.isAlive = true;
                        }
                        if(ball.hitbox.intersects(e.rect)) {
                          e.isAlive = false;
               }
                        if(sphere.hitbox.intersects(e.rect)) {
                            e.speed = 0f;
                        }

                        if(magic.hitbox.intersects(e.rect)) {
                            e.Bx = 1000;
                            e.By = 1000;
               }
                 }
                       
                 }
                 if (ball.isIsVisible()) {
                     if (ball.getTimeexists() > 0) {
                     if (ball.getDirection() == 0) {
                         ball.setX((int)skully.x);
                         ball.setY(ball.getY() - 5);
                     } else if (ball.getDirection() == 2) {
                         ball.setX((int) skully.x);
                         ball.setY(ball.getY() + 5);
                     } else if (ball.getDirection() == 3) {
                         ball.setX(ball.getX() - 5);
                         ball.setY(ball.getY());
                     } else if (ball.getDirection() == 1) {
                         ball.setX(ball.getX() + 5);
                         ball.setY(ball.getY());
                     }
                     ball.hitbox.setX(ball.getX());
                     ball.hitbox.setY(ball.getY());
                     ball.countdown();
                 } else {
                     ball.setIsVisible(false);
                 }
                 }
                 if (sphere.isIsVisible()) {
                     if (sphere.getTimeexists() > 0) {
                     if (sphere.getDirection() == 0) {
                         sphere.setX((int)skully.x);
                         sphere.setY(sphere.getY() - 5);
                     } else if (sphere.getDirection() == 2) {
                         sphere.setX((int) skully.x);
                         sphere.setY(sphere.getY() + 5);
                     } else if (sphere.getDirection() == 3) {
                         sphere.setX(sphere.getX() - 5);
                         sphere.setY(sphere.getY());
                     } else if (sphere.getDirection() == 1) {
                         sphere.setX(sphere.getX() + 5);
                         sphere.setY(sphere.getY());
                     }
                     sphere.hitbox.setX(sphere.getX());
                     sphere.hitbox.setY(sphere.getY());
                     sphere.countdown();
                     
                 } else {
                     sphere.setIsVisible(false);
                 }
        }
                  if (magic.isIsVisible()) {
                      if (magic.getTimeexists() > 0) {
                     if (magic.getDirection() == 0) {
                         magic.setX((int)skully.x);
                         magic.setY(magic.getY() - 5);
                     } else if (magic.getDirection() == 2) {
                         magic.setX((int) skully.x);
                         magic.setY(magic.getY() + 5);
                     } else if (magic.getDirection() == 3) {
                         magic.setX(magic.getX() - 5);
                         ball.setY(magic.getY());
                     } else if (magic.getDirection() == 1) {
                         magic.setX(magic.getX() + 5);
                         magic.setY(magic.getY());
                     }
                     magic.hitbox.setX(magic.getX());
                     magic.hitbox.setY(magic.getY());
                     magic.countdown();
                 } else {
                     magic.setIsVisible(false);
                 }
        }
                 

		if(skully.health <= 0){
			sbg.enterState(2, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
		}
                if(skully.stamina <= 1){
			sbg.enterState(5, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
		}

	}

	public int getID() {

		return 1;

	}

                
	
	private boolean isBlocked(float tx, float ty) {

		int xBlock = (int) tx / SIZE;

		int yBlock = (int) ty / SIZE;

		return Blocked.blocked[xBlock][yBlock];

	}

}
