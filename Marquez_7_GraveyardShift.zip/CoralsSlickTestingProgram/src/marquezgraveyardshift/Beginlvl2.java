/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marquezgraveyardshift;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author freyes
 */
public class Beginlvl2 extends BasicGameState{
    private StateBasedGame game;
    public Image startimage;

    public Beginlvl2(int xSize, int ySize) {

    }

    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        startimage = new Image("res/lvl2.png");

        this.game = game;

    }
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {

        startimage.draw();

    }


    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {

    }

    public int getID() {

        return 7;

    }


    public void keyReleased(int key, char c) {

        switch (key) {

            case Input.KEY_1:

                GraveyardShiftlvl1.skully.health = 100000;
                GraveyardShiftlvl1.skully.speed = .4f;
                GraveyardShiftlvl1.counter = 0;
                
                Player.x = 96f;
                Player.y = 228f;
                Player.Counter = 0;
        {
            try {
                BoneMaker.Makethebones();
            } catch (SlickException ex) {
                Logger.getLogger(lose.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
                game.enterState(6, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));

                break;

            case Input.KEY_2:

                break;

            case Input.KEY_3:

                break;

            default:

                break;

        }

    }
}
