/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marquezgraveyardshift;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

/**
 *
 * @author freyes
 */
public class Orb {
    private int x, y, width, height;
    private int dmg , locationX , locationY;
    private boolean isVisible;
    Image orb;
    Shape hitbox;
    
    public Orb (int a, int b) throws SlickException {
        this.x = a;
        this.y = b;
        this.isVisible = false;
        this.orb = new Image ("res/orbs/Ninja_12.png");
        this.hitbox = new Rectangle (a, b, 32, 32);
    }
    /*
    Getters and setters are a common concept in java
    A design guidline in java, and object oriented 
    programming in general, is to encapsulate/isolate
    values as much as possible 
    Getters- are methods used to query the value of
    instance variables
    query- to look up/find data 
    this.getLocationX();
    Setters- methods that set values for the instance 
    variables
    orb1.setLocation(Player.x, Player.y);
    */

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getDmg() {
        return dmg;
    }

    public int getLocationX() {
        return locationX;
    }

    public int getLocationY() {
        return locationY;
    }

    public boolean isIsVisible() {
        return isVisible;
    }

    public Image getOrb() {
        return orb;
    }

    public Shape getHitbox() {
        return hitbox;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setDmg(int dmg) {
        this.dmg = dmg;
    }

    public void setLocationX(int locationX) {
        this.locationX = locationX;
    }

    public void setLocationY(int locationY) {
        this.locationY = locationY;
    }

/*    public void set Location (int a, int b) {
        ball.setIsVisible(true);
        ball.setX(player.X);
        ball.setY(player.Y);
        ball.setHitboxX(player.x + 5);
        ball.setHitboxY(player.y -10);
    }
*/    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    public void setOrb(Image orb) {
        this.orb = orb;
    }

    public void setHitbox(Shape hitbox) {
        this.hitbox = hitbox;
    }

    void setX(float x) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setY(float y) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
