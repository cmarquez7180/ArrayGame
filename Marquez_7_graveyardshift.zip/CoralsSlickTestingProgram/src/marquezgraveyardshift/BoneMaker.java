/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marquezgraveyardshift;

import java.util.ArrayList;
import org.newdawn.slick.SlickException;
import static marquezgraveyardshift.GraveyardShiftlvl1.doghouse;
import static marquezgraveyardshift.GraveyardShiftlvl1.grassMap;

/**
 *
 * @author freyes
 */
public class BoneMaker {
    static int width = grassMap.getWidth();
    static int SIZE = 64;
   
    public static void Makethebones () throws SlickException{
        GraveyardShiftlvl1.doghouse = new ArrayList();
    for (int xAxis = 0; xAxis < width; xAxis++) {
			for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
				int xBlock = (int) xAxis;
				int yBlock = (int) yAxis;
				if (!Blocked.blocked[xBlock][yBlock]) {
					if (yBlock % 12 == 0 && xBlock % 11 == 0 ) {
						Bone b = new Bone(xAxis * SIZE, yAxis * SIZE);
						GraveyardShiftlvl1.doghouse.add(b);
						//stuff1.add(h);
						//hostiles[xAxis][yAxis] = true;
					}
				}
			}
		}
    
}
}
